package br.com.bruna.rm83421

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_login.*



class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //Criando o clique do botão Entrar
        btnEntrar.setOnClickListener {
            //Recuperando valores digitados
            val usuario = edtUsuario.text.toString().trim()
            val senha = editTextTextPassword.text.toString().trim()

            //Criando a condição para verificar se usuário e/ou senha estão vazios/corretos
            if(usuario.isEmpty()){
                Toast.makeText(this@LoginActivity, "Usuário Vazio!", Toast.LENGTH_SHORT).show()
            }else if(senha.isEmpty()){
                Toast.makeText(this@LoginActivity, "Senha Vazia!", Toast.LENGTH_SHORT).show()
            }else if(usuario == "Bruna"){
                if(senha == "12345"){
                    startActivity( Intent(this@LoginActivity, MainActivity::class.java))
                }else{
                    Toast.makeText(this@LoginActivity, "Senha Incorreta", Toast.LENGTH_SHORT).show()
                }
            }else{
                Toast.makeText(this@LoginActivity, "Usuário Incorreto!", Toast.LENGTH_SHORT).show()
            }
        }

        //Criando a interação do botão Cadastrar
        btnCadastrar.setOnClickListener {
            startActivity(Intent(this@LoginActivity, CadastroActivity::class.java))
        }
    }

}