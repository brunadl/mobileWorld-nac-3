package br.com.bruna.rm83421

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_web.*

class WebActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)

        //Habilitar o JS do site do cellep
        wbvWeb.settings.javaScriptEnabled = true

        wbvWeb.loadUrl("https://www2.fiap.com.br/")
    }
}